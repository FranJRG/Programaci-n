print(7>=27 and not(7<=2))
print(24>5 and 10<=10 or 10==5)
print((10>=15 or 23==13) and not(8==8))
print(not (6/3>3) or 7>7)